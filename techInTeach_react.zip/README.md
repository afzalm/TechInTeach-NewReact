# TechInTeach Project

## Project Overview

This is a modern web application built with Vite, React, TypeScript, and shadcn-ui.